<?php

namespace App\Filament\Resources\TujuanResource\Pages;

use App\Filament\Resources\TujuanResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTujuan extends CreateRecord
{
    protected static string $resource = TujuanResource::class;
}
