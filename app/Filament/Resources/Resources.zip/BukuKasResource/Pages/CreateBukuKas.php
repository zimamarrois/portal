<?php

namespace App\Filament\Resources\BukuKasResource\Pages;

use App\Filament\Resources\BukuKasResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBukuKas extends CreateRecord
{
    protected static string $resource = BukuKasResource::class;
}
