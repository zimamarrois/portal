<?php

namespace App\Filament\Resources\KeluarResource\Pages;

use App\Filament\Resources\KeluarResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKeluar extends CreateRecord
{
    protected static string $resource = KeluarResource::class;
}
