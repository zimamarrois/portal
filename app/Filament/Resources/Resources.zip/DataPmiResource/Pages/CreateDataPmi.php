<?php

namespace App\Filament\Resources\DataPmiResource\Pages;

use App\Filament\Resources\DataPmiResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataPmi extends CreateRecord
{
    protected static string $resource = DataPmiResource::class;
}
