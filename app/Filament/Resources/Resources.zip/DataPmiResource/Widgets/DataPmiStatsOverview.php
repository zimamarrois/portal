<?php

namespace App\Filament\Resources\DataPmiResource\Widgets;

use App\Models\DataPmi;
use App\Models\Pendaftaran;
use App\Models\Tujuan;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Card;

class DataPmiStatsOverview extends BaseWidget
{
    protected function getCards(): array
    {
        
        $NONJOB = DataPmi::where('job','0')->count();
        $JOB = DataPmi::where('job','1')->count();
        $PMIFinish = DataPmi::where('status_update_id','18')->count();
        $PMIMD = DataPmi::where('status_update_id','19')->count();
        $PMIPending = DataPmi::where('status_update_id','21')->count();

        $TotalJob = $JOB - $PMIFinish;
        $TotalNonJob = $NONJOB - $PMIPending - $PMIMD;

        return [
            Card::make('DATA PMI', DataPmi::all()->count())
            ->description('Total Proses ')
            ->descriptionIcon('heroicon-o-check-circle')
            ->color('success'),

            Card::make('PENDAFTARAN', Pendaftaran::all()->count())
            ->description('Total Pendaftar')
            ->descriptionIcon('heroicon-o-clipboard-check')
            ->color('#D6254D'),

            Card::make('JOB',($TotalJob))
            ->description('Sudah Dapat Job')
            ->descriptionIcon('heroicon-o-clipboard-check')
            ->color('success'),

            Card::make('NON JOB',($TotalNonJob))
            ->description('Belum Dapat Job')
            ->descriptionIcon('heroicon-o-clipboard-check')
            ->color('danger'),
            
        ];
    }
}
